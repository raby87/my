<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/5/14
 * Time: 1:24
 */


require __DIR__.'/vendor/autoload.php';

(new \Ioc\App())->boot();
